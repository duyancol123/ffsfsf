/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbconnect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Duck
 */
public class MyConnection {
    static String hostName = "localhost";
 
    static String dbName = "bakery";
    static String userName = "root";
    static String password = "";
    public static Connection getConnection() throws ClassNotFoundException, SQLException{
        Class.forName("com.mysql.jdbc.Driver");
        String connectionURL = "jdbc:mysql://" + hostName + ":3306/" + dbName + "?useUnicode=yes&characterEncoding=UTF-8&useFastDateParsing=false";
        Connection conn = DriverManager.getConnection(connectionURL, userName,
             password);
        return conn;
    }
}
