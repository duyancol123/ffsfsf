package modelDAO;

public abstract class DAO {
	
}
